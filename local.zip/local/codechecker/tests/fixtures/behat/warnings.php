<?php

// This is commented out code (63%) => warning.

// echo·$OUTPUT->page_heading();

// This is commented out code (54%) => warning.

// foreach ($something as $someone) { // Still too much.

// But this (28%) is under the thresold (40%) => pass.

// This is a comment: $a = abs($b + 100);
